import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { Problem } from "@/components/problem"
import { Features } from "@/components/features"
import { Methodology } from "@/components/methodology"
import { Results } from "@/components/results"
import { Team } from "@/components/team"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Problem />
      <Features />
      <Methodology />
      <Results />
      <Team />
      <Footer />
    </main>
  )
}
