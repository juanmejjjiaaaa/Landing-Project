import { GraduationCap, Building2, Users } from "lucide-react"

const teamMembers = [
  { name: "Juan Fernando Mejía Álvarez", role: "Investigador / Ponente" },
  { name: "Juan Pablo Arango Bedoya", role: "Investigador" },
  { name: "Juan Pablo Gómez Carmona", role: "Investigador / Ponente" },
  { name: "Santiago Munera Rave", role: "Investigador" },
]

export function Team() {
  return (
    <section id="equipo" className="py-20 md:py-32 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Equipo de investigación
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            Estudiantes de Ingeniería Informática comprometidos con la sostenibilidad 
            y la innovación tecnológica.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {teamMembers.map((member, index) => (
            <div
              key={index}
              className="bg-card p-6 rounded-2xl border border-border text-center hover:border-primary/50 transition-colors"
            >
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-primary">
                  {member.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                </span>
              </div>
              <h3 className="font-semibold text-foreground mb-1">{member.name}</h3>
              <p className="text-sm text-muted-foreground">{member.role}</p>
            </div>
          ))}
        </div>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-card p-6 rounded-2xl border border-border flex items-center gap-4">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
              <Building2 className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Institución</p>
              <p className="font-semibold text-foreground">Corporación Universitaria Lasallista</p>
            </div>
          </div>
          
          <div className="bg-card p-6 rounded-2xl border border-border flex items-center gap-4">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
              <Users className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Semillero</p>
              <p className="font-semibold text-foreground">DEDALOS</p>
            </div>
          </div>
          
          <div className="bg-card p-6 rounded-2xl border border-border flex items-center gap-4">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
              <GraduationCap className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Programa</p>
              <p className="font-semibold text-foreground">Ingeniería Informática</p>
            </div>
          </div>
        </div>
        
        <div className="mt-12 bg-primary text-primary-foreground p-8 md:p-12 rounded-2xl text-center">
          <h3 className="text-2xl font-bold mb-4">EDSIN 2026</h3>
          <p className="text-primary-foreground/80 mb-2">
            Proyecto presentado en el Encuentro Departamental de Semilleros de Investigación
          </p>
          <p className="text-sm text-primary-foreground/60">
            Nodo Antioquia • Red Colombiana de Semilleros de Investigación (RedCOLSI)
          </p>
        </div>
      </div>
    </section>
  )
}
