import { Recycle, Calculator, Gamepad2, Target, BarChart2, Award } from "lucide-react"

const features = [
  {
    icon: Recycle,
    title: "Clasificación inteligente",
    description: "Procesa la información suministrada para clasificar residuos en categorías: reciclable, orgánico, peligroso o no reciclable.",
  },
  {
    icon: Calculator,
    title: "Cálculo de huella de carbono",
    description: "Estima tu huella de carbono personal y global mediante la fórmula: cantidad de residuos × factor de emisión.",
  },
  {
    icon: Gamepad2,
    title: "Sistema de gamificación",
    description: "Incentiva la participación a través de puntos y tareas diarias que otorgan beneficios institucionales.",
  },
  {
    icon: Target,
    title: "Objetivos de desarrollo sostenible",
    description: "Alineado con los ODS 4 (Educación de calidad) y ODS 11 (Ciudades sostenibles).",
  },
  {
    icon: BarChart2,
    title: "Métricas en tiempo real",
    description: "Estadísticas sobre la huella de carbono institucional para la toma de decisiones administrativas.",
  },
  {
    icon: Award,
    title: "Nivel de Conciencia Ambiental",
    description: "Seguimiento del NCA mediante el registro de tareas completadas y puntos acumulados.",
  },
]

export function Features() {
  return (
    <section id="caracteristicas" className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Características del sistema
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            Un prototipo web interactivo diseñado para facilitar la clasificación 
            de residuos en el origen, utilizando tecnologías modernas.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative p-8 rounded-2xl bg-card border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <feature.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
