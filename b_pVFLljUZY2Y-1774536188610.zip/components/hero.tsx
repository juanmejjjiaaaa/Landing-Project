import { Button } from "@/components/ui/button"
import { ArrowRight, Leaf, BarChart3, Trophy } from "lucide-react"

export function Hero() {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-secondary px-4 py-2 rounded-full mb-6">
              <Leaf className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-foreground">ODS 4 y 11</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
              Transforma la gestión de residuos en tu
              <span className="text-primary"> universidad</span>
            </h1>
            
            <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 text-pretty">
              Sistema clasificador de residuos sólidos que combina gamificación y métricas ambientales 
              para educar y motivar comportamientos sostenibles en instituciones de educación superior.
            </p>
            
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button size="lg" className="gap-2">
                Comenzar ahora
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline">
                Ver demostración
              </Button>
            </div>
            
            <div className="mt-12 grid grid-cols-3 gap-6">
              <div className="text-center lg:text-left">
                <p className="text-3xl font-bold text-foreground">70-80%</p>
                <p className="text-sm text-muted-foreground">Residuos aprovechables</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-3xl font-bold text-foreground">12-17%</p>
                <p className="text-sm text-muted-foreground">Reciclaje actual</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-3xl font-bold text-primary">+50%</p>
                <p className="text-sm text-muted-foreground">Mejora esperada</p>
              </div>
            </div>
          </div>
          
          <div className="relative lg:pl-8">
            <div className="relative bg-card rounded-2xl border border-border shadow-xl overflow-hidden">
              <div className="bg-primary/10 p-6 border-b border-border">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                    <Leaf className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">BinSorter A.M.G</p>
                    <p className="text-sm text-muted-foreground">Panel de control</p>
                  </div>
                </div>
              </div>
              
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between p-4 bg-secondary rounded-xl">
                  <div className="flex items-center gap-3">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-foreground">Huella de Carbono</span>
                  </div>
                  <span className="text-sm font-bold text-primary">-23.5 kg CO₂</span>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-secondary rounded-xl">
                  <div className="flex items-center gap-3">
                    <Trophy className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-foreground">Puntos acumulados</span>
                  </div>
                  <span className="text-sm font-bold text-primary">1,250 pts</span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Progreso semanal</span>
                    <span className="font-medium text-foreground">78%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full w-[78%] bg-primary rounded-full" />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-primary/20 rounded-full blur-3xl" />
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-accent/20 rounded-full blur-2xl" />
          </div>
        </div>
      </div>
    </section>
  )
}
