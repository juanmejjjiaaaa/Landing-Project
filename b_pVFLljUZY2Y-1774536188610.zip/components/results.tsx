import { CheckCircle2, TrendingUp, Users, Database } from "lucide-react"

const expectedResults = [
  {
    icon: CheckCircle2,
    title: "Mejor clasificación",
    description: "Mejora significativa en la precisión de la separación de residuos por parte de los estudiantes gracias a la guía del prototipo.",
  },
  {
    icon: TrendingUp,
    title: "Estadísticas en tiempo real",
    description: "Generación de estadísticas sobre la huella de carbono institucional para la toma de decisiones administrativas.",
  },
  {
    icon: Users,
    title: "Mayor participación",
    description: "Aumento de la motivación estudiantil para participar en jornadas ambientales motivados por el sistema de incentivos.",
  },
  {
    icon: Database,
    title: "Base de datos consolidada",
    description: "Identificación de tendencias de consumo y tipos de residuos más frecuentes en el campus.",
  },
]

export function Results() {
  return (
    <section id="resultados" className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <span className="inline-block text-sm font-medium text-primary mb-4">Investigación en curso</span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
              Resultados esperados
            </h2>
            <p className="text-lg text-muted-foreground mb-8 text-pretty">
              El proyecto busca demostrar que la tecnología interactiva y la gamificación 
              pueden transformar los hábitos de gestión de residuos en las universidades colombianas.
            </p>
            
            <div className="space-y-6">
              {expectedResults.map((result, index) => (
                <div key={index} className="flex gap-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                    <result.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">{result.title}</h3>
                    <p className="text-sm text-muted-foreground">{result.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-card rounded-2xl border border-border p-8">
              <h3 className="text-lg font-semibold text-foreground mb-6">Impacto proyectado</h3>
              
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Tasa de reciclaje actual</span>
                    <span className="text-sm font-medium text-foreground">12-17%</span>
                  </div>
                  <div className="h-3 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full w-[15%] bg-muted-foreground/50 rounded-full" />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Meta con BinSorter</span>
                    <span className="text-sm font-medium text-primary">+50%</span>
                  </div>
                  <div className="h-3 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full w-[65%] bg-primary rounded-full" />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Objetivo basura cero</span>
                    <span className="text-sm font-medium text-foreground">70%</span>
                  </div>
                  <div className="h-3 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full w-[70%] bg-accent rounded-full" />
                  </div>
                </div>
              </div>
              
              <div className="mt-8 p-4 bg-primary/10 rounded-xl">
                <p className="text-sm text-foreground">
                  <span className="font-semibold">Dato clave:</span> Un diagnóstico de la Universidad Católica de Manizales 
                  documentó tasas de recuperación de 38% (2022), 32% (2023) y 44% (2024), 
                  demostrando la capacidad de mejora institucional.
                </p>
              </div>
            </div>
            
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-primary/10 rounded-full blur-3xl -z-10" />
          </div>
        </div>
      </div>
    </section>
  )
}
