import { FileSearch, Code2, Database, TrendingUp } from "lucide-react"

const steps = [
  {
    number: "1",
    icon: FileSearch,
    title: "Análisis Documental",
    description: "Revisión de las prácticas actuales de gestión de residuos y datos históricos de generación en la institución.",
  },
  {
    number: "2",
    icon: Code2,
    title: "Diseño Tecnológico",
    description: "Desarrollo del prototipo utilizando lenguajes de programación web para el procesamiento de datos y la interfaz de usuario.",
  },
  {
    number: "3",
    icon: Database,
    title: "Recolección de Datos",
    description: "Los estudiantes proveerán información sobre los residuos a eliminar a través de la plataforma web.",
  },
  {
    number: "4",
    icon: TrendingUp,
    title: "Evaluación de Impacto",
    description: "Seguimiento del NCA mediante el registro de tareas completadas y puntos acumulados en el sistema de gamificación.",
  },
]

export function Methodology() {
  return (
    <section id="metodologia" className="py-20 md:py-32 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Metodología de investigación
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            El proyecto sigue un enfoque mixto (cualitativo y cuantitativo) 
            con un diseño descriptivo y exploratorio.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-card p-6 rounded-2xl border border-border h-full">
                <div className="flex items-center gap-4 mb-4">
                  <span className="text-4xl font-bold text-primary/20">{step.number}</span>
                  <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                    <step.icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                </div>
                <h3 className="font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </div>
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-border" />
              )}
            </div>
          ))}
        </div>
        
        <div className="mt-16 p-8 bg-card rounded-2xl border border-border">
          <h3 className="text-xl font-semibold text-foreground mb-4">Referente Teórico</h3>
          <p className="text-muted-foreground mb-4 text-pretty">
            La investigación se fundamenta en la <span className="font-medium text-foreground">Economía Circular</span>, 
            un modelo que busca cerrar el ciclo de vida de los productos minimizando el desperdicio 
            y reincorporando materiales al sistema productivo.
          </p>
          <p className="text-muted-foreground text-pretty">
            Se integra la normativa colombiana de clasificación de residuos, específicamente la 
            <span className="font-medium text-foreground"> Resolución 2184 de 2019</span>, que establece el código de colores 
            (blanco, verde y negro) para la separación en la fuente.
          </p>
        </div>
      </div>
    </section>
  )
}
