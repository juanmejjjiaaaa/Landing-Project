import { AlertTriangle, Trash2, TrendingDown, Users } from "lucide-react"

const problems = [
  {
    icon: Trash2,
    title: "Mezcla de residuos",
    description: "La problemática principal radica en la mezcla de residuos desde la fuente, generando focos de contaminación.",
  },
  {
    icon: TrendingDown,
    title: "Bajo aprovechamiento",
    description: "Solo se aprovecha entre el 12% y 17% de los residuos, cuando el 70-80% son potencialmente reciclables.",
  },
  {
    icon: Users,
    title: "Falta de motivación",
    description: "Desconocimiento de normativas y ausencia de cultura ambiental en la comunidad universitaria.",
  },
  {
    icon: AlertTriangle,
    title: "Huella de carbono",
    description: "Aumento innecesario de la huella de carbono institucional por prácticas inadecuadas de gestión.",
  },
]

export function Problem() {
  return (
    <section id="problema" className="py-20 md:py-32 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            El problema de los residuos en las universidades
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            Las instituciones de educación superior enfrentan desafíos significativos 
            en la gestión integral de residuos sólidos (GIRS).
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {problems.map((problem, index) => (
            <div
              key={index}
              className="bg-card p-6 rounded-2xl border border-border hover:border-primary/50 transition-colors"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                <problem.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{problem.title}</h3>
              <p className="text-sm text-muted-foreground">{problem.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 bg-card rounded-2xl border border-border p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-4 text-balance">
                La solución: Educación + Tecnología + Gamificación
              </h3>
              <p className="text-muted-foreground text-pretty">
                BinSorter A.M.G propone transformar las IES en campus sostenibles 
                que lideren el cambio cultural hacia la economía circular, 
                abordando el problema desde la raíz: la educación y sensibilización del generador.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="aspect-square bg-[#f5f5f5] rounded-2xl flex items-center justify-center border-2 border-dashed border-muted-foreground/20">
                <div className="text-center">
                  <div className="w-8 h-8 mx-auto bg-[#f5f5f5] border-2 border-foreground/20 rounded-lg mb-2" />
                  <span className="text-xs text-muted-foreground">Blanco</span>
                  <p className="text-[10px] text-muted-foreground">Reciclable</p>
                </div>
              </div>
              <div className="aspect-square bg-primary/20 rounded-2xl flex items-center justify-center border-2 border-dashed border-primary/30">
                <div className="text-center">
                  <div className="w-8 h-8 mx-auto bg-primary rounded-lg mb-2" />
                  <span className="text-xs text-muted-foreground">Verde</span>
                  <p className="text-[10px] text-muted-foreground">Orgánico</p>
                </div>
              </div>
              <div className="aspect-square bg-foreground/5 rounded-2xl flex items-center justify-center border-2 border-dashed border-foreground/20">
                <div className="text-center">
                  <div className="w-8 h-8 mx-auto bg-foreground rounded-lg mb-2" />
                  <span className="text-xs text-muted-foreground">Negro</span>
                  <p className="text-[10px] text-muted-foreground">No reciclable</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
