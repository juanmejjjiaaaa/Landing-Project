import Link from "next/link"
import { Recycle, Mail, MapPin, BookOpen } from "lucide-react"

const references = [
  "Cantor, E. L., et al. (2023). Sistema empresarial inteligente para la clasificación de residuos.",
  "Gomez, I. N., Chaves, S. F., & Gómez, J. A. (2025). La enseñanza del manejo integral de residuos sólidos a través de la IA.",
  "Hortua, A. S., et al. (2026). Hacia un campus basura cero en la educación superior.",
  "Pino, C., et al. (2024). Modelo de economía circular para los institutos técnicos y tecnológicos.",
]

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Recycle className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-semibold text-background">BinSorter A.M.G</span>
            </Link>
            <p className="text-background/60 text-sm">
              Sistema clasificador de residuos sólidos en instituciones de educación superior.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-background mb-4">Enlaces</h4>
            <ul className="space-y-2">
              <li>
                <Link href="#problema" className="text-sm text-background/60 hover:text-background transition-colors">
                  Problema
                </Link>
              </li>
              <li>
                <Link href="#caracteristicas" className="text-sm text-background/60 hover:text-background transition-colors">
                  Características
                </Link>
              </li>
              <li>
                <Link href="#metodologia" className="text-sm text-background/60 hover:text-background transition-colors">
                  Metodología
                </Link>
              </li>
              <li>
                <Link href="#resultados" className="text-sm text-background/60 hover:text-background transition-colors">
                  Resultados
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-background mb-4">Contacto</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-background/60">
                <Mail className="w-4 h-4" />
                jgomez88@unilasallista.edu.co
              </li>
              <li className="flex items-center gap-2 text-sm text-background/60">
                <MapPin className="w-4 h-4" />
                Corporación Universitaria Lasallista
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-background mb-4 flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Referencias
            </h4>
            <ul className="space-y-2">
              {references.map((ref, index) => (
                <li key={index} className="text-xs text-background/50">
                  {ref}
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-background/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-background/60">
            © 2026 BinSorter A.M.G. Todos los derechos reservados.
          </p>
          <p className="text-sm text-background/40">
            Semillero DEDALOS • Ingeniería Informática • 1er Semestre
          </p>
        </div>
      </div>
    </footer>
  )
}
